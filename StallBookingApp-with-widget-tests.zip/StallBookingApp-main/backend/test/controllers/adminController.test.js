const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const argon2 = require('argon2');
const Booking = require('../../models/Booking');
const User = require('../../models/User');
const adminController = require('../../controllers/adminController');
const {
  createResponse,
  withOverrides,
  withMutedConsoleError
} = require('../../test-support/controllerHarness');

describe('adminController.getPendingBookings and verifyBooking', () => {
  // จำลองโมเดลคืน booking สถานะ pending หนึ่งรายการ แล้วตรวจว่า controller ส่งรายการนั้นกลับโดยไม่เปลี่ยนข้อมูล
  it('returns pending bookings', async () => {
    const response = createResponse();
    const bookings = [{ id: 4, status: 'pending' }];

    await withOverrides(
      [[Booking, 'findPending', async () => bookings]],
      () => adminController.getPendingBookings({}, response)
    );

    assert.deepEqual(response.body, bookings);
  });

  // ส่ง ID ที่เป็นศูนย์และ status ที่ไม่ใช่ approved/rejected แล้วคาดหวัง HTTP 400 ทั้งสองกรณี
  it('validates booking ID and requested decision', async () => {
    const cases = [
      [{ id: '0' }, { status: 'approved' }],
      [{ id: '4' }, { status: 'pending' }]
    ];

    for (const [params, body] of cases) {
      const response = createResponse();
      await adminController.verifyBooking({ params, body }, response);
      assert.equal(response.statusCode, 400);
    }
  });

  // จำลอง booking ที่หาไม่พบและ booking ที่อนุมัติไปแล้ว: คาดหวัง 404 และ 409 ตามลำดับ
  it('rejects missing and already reviewed bookings', async () => {
    for (const { booking, statusCode } of [
      { booking: undefined, statusCode: 404 },
      { booking: { id: 4, status: 'approved' }, statusCode: 409 }
    ]) {
      const response = createResponse();
      await withOverrides(
        [[Booking, 'findById', async () => booking]],
        () => adminController.verifyBooking({
          params: { id: '4' }, body: { status: 'approved' }
        }, response)
      );
      assert.equal(response.statusCode, statusCode);
    }
  });

  // ลองอนุมัติโดยไม่มีสลิป และด้วยยอดชำระไม่ตรงราคา: ทั้งคู่ต้องถูกปฏิเสธด้วย 409 พร้อมข้อความสาเหตุ
  it('requires a slip and matching amount before approval', async () => {
    for (const { booking, expectedMessage } of [
      {
        booking: { id: 4, status: 'pending', slip_url: null, price: 250, payment_amount: 250 },
        expectedMessage: 'A payment slip must be submitted before approval.'
      },
      {
        booking: { id: 4, status: 'pending', slip_url: '/uploads/slips/a.png', price: 250, payment_amount: 240 },
        expectedMessage: 'The submitted payment amount does not match the booking price.'
      }
    ]) {
      const response = createResponse();
      await withOverrides(
        [[Booking, 'findById', async () => booking]],
        () => adminController.verifyBooking({
          params: { id: '4' }, body: { status: 'approved' }
        }, response)
      );
      assert.equal(response.statusCode, 409);
      assert.equal(response.body.message, expectedMessage);
    }
  });

  // เมื่อ booking pending มีสลิปและยอดตรงราคา ตรวจว่าอัปเดตเป็น approved และตอบ booking ID/status โดยไม่บันทึก metadata ผู้อนุมัติ
  it('approves an eligible booking without storing approval metadata', async () => {
    const response = createResponse();
    let updateArguments;
    const booking = {
      id: 4,
      status: 'pending',
      slip_url: '/uploads/slips/a.png',
      price: '250.00',
      payment_amount: '250.00'
    };

    await withOverrides(
      [
        [Booking, 'findById', async () => booking],
        [Booking, 'updatePendingStatus', async (...args) => { updateArguments = args; return true; }]
      ],
      () => adminController.verifyBooking({
        params: { id: '4' }, body: { status: 'approved' }, user: { id: 99 }
      }, response)
    );

    assert.deepEqual(updateArguments, [4, 'approved']);
    assert.deepEqual(response.body, {
      message: 'Booking has been approved.', bookingId: 4, status: 'approved'
    });
  });

  // ตรวจว่าปฏิเสธ booking pending ได้ และหากการอัปเดตไม่สำเร็จเพราะมีคำขออื่นเปลี่ยนสถานะก่อน ต้องตอบ 409
  it('can reject a pending booking and handles a concurrent update', async () => {
    const rejectedResponse = createResponse();
    const booking = { id: 4, status: 'pending', slip_url: null };

    await withOverrides(
      [
        [Booking, 'findById', async () => booking],
        [Booking, 'updatePendingStatus', async () => true]
      ],
      () => adminController.verifyBooking({
        params: { id: '4' }, body: { status: 'rejected' }, user: { id: 99 }
      }, rejectedResponse)
    );
    assert.equal(rejectedResponse.body.status, 'rejected');

    const conflictResponse = createResponse();
    await withOverrides(
      [
        [Booking, 'findById', async () => booking],
        [Booking, 'updatePendingStatus', async () => false]
      ],
      () => adminController.verifyBooking({
        params: { id: '4' }, body: { status: 'rejected' }, user: { id: 99 }
      }, conflictResponse)
    );
    assert.equal(conflictResponse.statusCode, 409);
  });
});

describe('adminController analytics and user management', () => {
  // วันที่ไม่มีจริงต้องได้ 400; วันที่ถูกต้องต้องถูกส่งเข้าโมเดลและส่ง analytics ที่ได้กลับไป
  it('validates and returns analytics for the requested date', async () => {
    const invalidResponse = createResponse();
    await adminController.getAnalytics({ query: { date: '2026-02-30' } }, invalidResponse);
    assert.equal(invalidResponse.statusCode, 400);

    const response = createResponse();
    const analytics = { totalRevenue: 500 };
    let requestedDate;
    await withOverrides(
      [[Booking, 'getAnalytics', async (date) => { requestedDate = date; return analytics; }]],
      () => adminController.getAnalytics({ query: { date: '2099-01-02' } }, response)
    );
    assert.equal(requestedDate, '2099-01-02');
    assert.deepEqual(response.body, analytics);
  });

  // ส่งคำค้น `tea` จาก query string เข้า User.findAll และตรวจว่ารายชื่อผลลัพธ์ถูกส่งกลับครบ
  it('passes the optional vendor search query to the user model', async () => {
    const response = createResponse();
    const users = [{ id: 7, username: 'vendor7' }];
    let query;

    await withOverrides(
      [[User, 'findAll', async (value) => { query = value; return users; }]],
      () => adminController.getUsers({ query: { query: 'tea' } }, response)
    );

    assert.equal(query, 'tea');
    assert.deepEqual(response.body, users);
  });

  // ตรวจ ID ไม่ถูกต้องได้ 400, ID ที่ไม่มีผู้ใช้ได้ 404 และบัญชี admin ไม่สามารถถูกรีเซ็ตจากหน้าจัดการ vendor ได้
  it('validates user ID and only resets vendor accounts', async () => {
    const invalidId = createResponse();
    await adminController.resetUserPassword({ params: { id: '0' }, body: {} }, invalidId);
    assert.equal(invalidId.statusCode, 400);

    const missingUser = createResponse();
    await withOverrides(
      [[User, 'findById', async () => undefined]],
      () => adminController.resetUserPassword({ params: { id: '8' }, body: {} }, missingUser)
    );
    assert.equal(missingUser.statusCode, 404);

    const adminUser = createResponse();
    await withOverrides(
      [[User, 'findById', async () => ({ role: 'admin' })]],
      () => adminController.resetUserPassword({ params: { id: '8' }, body: {} }, adminUser)
    );
    assert.equal(adminUser.statusCode, 400);
  });

  // รีเซ็ตรหัส vendor ด้วยรหัสที่ส่งมา ตรวจว่า Argon2id รับรหัสนั้นและ hash ที่ได้ถูกบันทึก โดยไม่ส่ง hash กลับในข้อความตอบ
  it('hashes and saves the requested vendor password', async () => {
    const response = createResponse();
    let receivedHash;
    let receivedPassword;

    await withOverrides(
      [
        [User, 'findById', async () => ({ username: 'vendor8', role: 'vendor' })],
        [User, 'updatePassword', async (_id, hash) => { receivedHash = hash; }],
        [argon2, 'hash', async (password, options) => {
          receivedPassword = password;
          assert.equal(options.type, argon2.argon2id);
          return 'new-hash';
        }]
      ],
      () => adminController.resetUserPassword({
        params: { id: '8' }, body: { password: 'new-password-123' }
      }, response)
    );

    assert.equal(receivedPassword, 'new-password-123');
    assert.equal(receivedHash, 'new-hash');
    assert.match(response.body.message, /vendor8/);
  });

  // เมื่อไม่ส่ง password ให้ตรวจว่า controller hash ค่าเริ่มต้น `123456` และตอบสำเร็จ
  it('uses the reset command default when no password is provided', async () => {
    const response = createResponse();
    let hashedPassword;

    await withOverrides(
      [
        [User, 'findById', async () => ({ username: 'vendor8', role: 'vendor' })],
        [User, 'updatePassword', async () => true],
        [argon2, 'hash', async (password) => { hashedPassword = password; return 'hash'; }]
      ],
      () => adminController.resetUserPassword({
        params: { id: '8' }, body: {}
      }, response)
    );

    assert.equal(hashedPassword, '123456');
    assert.equal(response.statusCode, 200);
  });

  // เมื่อการค้นหารายการ pending โยน database error ให้ controller ตอบ HTTP 500
  it('returns server errors when admin lookups fail', async () => {
    const response = createResponse();

    await withMutedConsoleError(() => withOverrides(
      [[Booking, 'findPending', async () => { throw new Error('database down'); }]],
      () => adminController.getPendingBookings({}, response)
    ));

    assert.equal(response.statusCode, 500);
  });

  // จำลอง database error แยกใน analytics, ค้นหาผู้ใช้, ตรวจ booking และรีเซ็ตรหัสผ่าน แล้วตรวจว่าทุก endpoint ตอบ HTTP 500
  it('returns server errors for analytics, user search, verification, and reset failures', async () => {
    const scenarios = [
      {
        overrides: [[Booking, 'getAnalytics', async () => { throw new Error('query failed'); }]],
        action: (response) => adminController.getAnalytics({ query: { date: '2099-01-01' } }, response)
      },
      {
        overrides: [[User, 'findAll', async () => { throw new Error('query failed'); }]],
        action: (response) => adminController.getUsers({ query: {} }, response)
      },
      {
        overrides: [[Booking, 'findById', async () => { throw new Error('query failed'); }]],
        action: (response) => adminController.verifyBooking({
          params: { id: '4' }, body: { status: 'rejected' }
        }, response)
      },
      {
        overrides: [[User, 'findById', async () => { throw new Error('query failed'); }]],
        action: (response) => adminController.resetUserPassword({
          params: { id: '8' }, body: {}
        }, response)
      }
    ];

    for (const scenario of scenarios) {
      const response = createResponse();
      await withMutedConsoleError(() => withOverrides(
        scenario.overrides,
        () => scenario.action(response)
      ));
      assert.equal(response.statusCode, 500);
    }
  });
});
