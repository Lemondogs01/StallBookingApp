import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:mfu_market_app/controllers/auth_controller.dart';
import 'package:mfu_market_app/services/api_service.dart';
import 'package:mfu_market_app/views/auth/login_screen.dart';
import 'package:mfu_market_app/views/auth/register_screen.dart';

import 'controller_test_support.dart';

Finder field(String label) => find.byWidgetPredicate(
  (widget) => widget is TextFormField && widget.decoration.labelText == label,
);

void main() {
  late ApiService api;
  late AuthController auth;

  Future<void> pumpScreen(
    WidgetTester tester, {
    required Widget screen,
  }) async {
    await tester.view.setPhysicalSize(const Size(900, 1400));
    await tester.view.setDevicePixelRatio(1);
    await tester.pumpWidget(
      ChangeNotifierProvider<AuthController>.value(
        value: auth,
        child: MaterialApp(home: screen),
      ),
    );
    await tester.pumpAndSettle();
  }

  setUp(() {
    api = testApi((_) async => testJsonResponse({
      'message': 'Invalid username or password.',
    }, 401));
    auth = AuthController(api, MemoryStorage());
  });

  tearDown(() {
    auth.dispose();
    api.close();
  });

  group('LoginScreen Widget Test', () {
    testWidgets('renders login form and primary actions', (tester) async {
      await pumpScreen(tester, screen: const LoginScreen());

      expect(find.text('MFU Market'), findsOneWidget);
      expect(find.text('Sign in to book a daily market stall'), findsOneWidget);
      expect(find.byType(TextFormField), findsNWidgets(2));
      expect(find.text('Sign in'), findsOneWidget);
      expect(find.text('Forgot your password?'), findsOneWidget);
      expect(find.text('Create a vendor account'), findsOneWidget);
    });

    testWidgets('shows validation errors when submitted empty', (tester) async {
      await pumpScreen(tester, screen: const LoginScreen());

      await tester.tap(find.text('Sign in'));
      await tester.pumpAndSettle();

      expect(find.text('Enter your username.'), findsOneWidget);
      expect(find.text('Enter your password.'), findsOneWidget);
    });

    testWidgets('toggles password visibility', (tester) async {
      await pumpScreen(tester, screen: const LoginScreen());

      final passwordField = field('Password');
      expect(tester.widget<TextFormField>(passwordField).obscureText, isTrue);

      await tester.tap(find.byIcon(Icons.visibility_outlined));
      await tester.pump();

      expect(tester.widget<TextFormField>(passwordField).obscureText, isFalse);
    });

    testWidgets('opens the forgot-password help dialog', (tester) async {
      await pumpScreen(tester, screen: const LoginScreen());

      await tester.tap(find.text('Forgot your password?'));
      await tester.pumpAndSettle();

      expect(find.textContaining('Contact the market administrator to reset your password.'), findsOneWidget);
      expect(find.text('Got it'), findsOneWidget);
    });

    testWidgets('navigates to vendor registration', (tester) async {
      await pumpScreen(tester, screen: const LoginScreen());

      await tester.tap(find.text('Create a vendor account'));
      await tester.pumpAndSettle();

      expect(find.byType(RegisterScreen), findsOneWidget);
      expect(find.text('Create your vendor account'), findsOneWidget);
    });

    testWidgets('shows API authentication errors', (tester) async {
      await pumpScreen(tester, screen: const LoginScreen());

      await tester.enterText(field('Username'), 'vendor');
      await tester.enterText(field('Password'), 'wrong-password');
      await tester.tap(find.text('Sign in'));
      await tester.pumpAndSettle();

      expect(find.text('Invalid username or password.'), findsOneWidget);
    });
  });

  group('RegisterScreen Widget Test', () {
    testWidgets('renders all vendor registration fields', (tester) async {
      await pumpScreen(tester, screen: const RegisterScreen());

      expect(find.text('Create your vendor account'), findsOneWidget);
      expect(field('Shop name'), findsOneWidget);
      expect(field('Full name'), findsOneWidget);
      expect(field('Phone number'), findsOneWidget);
      expect(field('Username'), findsOneWidget);
      expect(field('Password'), findsOneWidget);
      expect(find.text('Create account'), findsOneWidget);
    });

    testWidgets('validates required registration fields', (tester) async {
      await pumpScreen(tester, screen: const RegisterScreen());

      await tester.tap(find.text('Create account'));
      await tester.pumpAndSettle();

      expect(find.text('Enter your Shop name.'), findsOneWidget);
      expect(find.text('Enter your Full name.'), findsOneWidget);
      expect(find.text('Enter your Phone number.'), findsOneWidget);
      expect(find.text('Enter your Username.'), findsOneWidget);
      expect(find.text('Enter your Password.'), findsOneWidget);
    });

    testWidgets('rejects invalid phone number and short password', (tester) async {
      await pumpScreen(tester, screen: const RegisterScreen());

      await tester.enterText(field('Shop name'), 'Tea Shop');
      await tester.enterText(field('Full name'), 'Vendor One');
      await tester.enterText(field('Phone number'), '123');
      await tester.enterText(field('Username'), 'vendor1');
      await tester.enterText(field('Password'), 'short');

      await tester.tap(find.text('Create account'));
      await tester.pumpAndSettle();

      expect(find.text('Enter a phone number with 8 to 15 digits.'), findsOneWidget);
      expect(find.text('Use at least 8 characters.'), findsOneWidget);
    });

    testWidgets('toggles registration password visibility', (tester) async {
      await pumpScreen(tester, screen: const RegisterScreen());

      final passwordField = field('Password');
      expect(tester.widget<TextFormField>(passwordField).obscureText, isTrue);

      await tester.tap(find.byTooltip('Show password'));
      await tester.pump();

      expect(tester.widget<TextFormField>(passwordField).obscureText, isFalse);
      expect(find.byTooltip('Hide password'), findsOneWidget);
    });
  });
}
